﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX07RawData
{
    public class Tire
    {
        public int Year { get; set; }

        public double Pressure { get; set; }

    }
}
